<?php

namespace App\Providers;

use App\NutritionProgram;
use App\Policies\NutritionProgramPolicy;
use App\Policies\UserPolicy;
use App\Policies\WorkoutProgramPolicy;
use App\User;
use App\WorkoutProgram;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        User::class => UserPolicy::class,
        WorkoutProgram::class => WorkoutProgramPolicy::class,
        NutritionProgram::class => NutritionProgramPolicy::class
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();
        //
    }
}
